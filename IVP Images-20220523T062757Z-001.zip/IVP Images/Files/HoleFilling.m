a=imread('boundary1.jpg');
subplot(1,2,1);imshow(a);
c=imfill(a,'holes');
subplot(1,2,2);imshow(c);
