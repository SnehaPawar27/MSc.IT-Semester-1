img1 = imread('monarch.png');
img_r=img1;
img_r(:,:,2)=0;
img_r(:,:,3)=0;

img_g=img1;
img_g(:,:,1)=0;
img_g(:,:,3)=0;


img_b=img1;
img_b(:,:,1)=0;
img_b(:,:,2)=0;

subplot(2,2,1);imshow(img1);title("Original image");
subplot(2,2,2);imshow(img_r);title("Red channel");
subplot(2,2,3);imshow(img_g);title("Green channel");
subplot(2,2,4);imshow(img_b);title("Blue channel");
