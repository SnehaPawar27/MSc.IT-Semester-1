clear all;
close all;
pkg load image;
a=imread('hawk1.png');
a=im2double(a);
r=imnoise(a,'salt & pepper' );
f=ones(3,3)/9;
af=filter2(f,r);
subplot(1,2,1);imshow(af); title('After applying average filter');
subplot(1,2,2)
imshow(r); title('noised image');