#load package of image
pkg load image;
#Take input image
img1=imread('monarch.png');
img=rgb2gray(img1);
#function to find edge using sobel filter
sobel = edge(img,'Sobel');

subplot(2,2,1)
imshow(img);
title('Original Image');
subplot(2,2,2)
imshow(sobel);
title("Edge detection using sobel filter");
#function to find edge using sobel filter
robert = edge(img,'Roberts');
prewitt = edge(img,'Prewitt');

subplot(2,2,3)
imshow(robert);
title('Edge detection using robert filter');
subplot(2,2,4)
imshow(prewitt);
title("Edge detection using prewitt filter");
