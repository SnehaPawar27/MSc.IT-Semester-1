
clear all;
close all;
ima=imread('leenanew.tif')
