myorigimg = imread('test.jpg');
A=im2bw(myorigimg);
thinf = bwmorph(A,'thin');
figure 2
subplot(2,2,1);
imshow(thinf);title('Thinning of the Image');
thickf = bwmorph(A,'thicken');
subplot(2,2,2);
imshow(thickf);title('Thickening of the Image');