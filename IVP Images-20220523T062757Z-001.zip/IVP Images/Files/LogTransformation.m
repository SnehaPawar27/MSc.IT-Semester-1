pkg load image;
clear all;
close all;
x = imread('monarch.png');
x = rgb2gray(x);
x = im2double(x);
[row col] = size(x);
c=2;
for i = 1:row 
  for j = 1:col
N(i,j)=c*log(1+x(i,j));
endfor
endfor
subplot(1,2,1);
imshow(x);
title('Original Image');
subplot(1,2,2);
imshow(N);
title('Log Transformation Filtered Image');