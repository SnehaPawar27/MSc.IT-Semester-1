close all
clear all
clc
pkg load image
a=imread('image1.tif');
b=imread('Sunflower.jpg');
e=rgb2gray(b);
c=255-a;
d=255-e;
subplot(3,3,1),imshow(a),title('Original Image 1');
subplot(3,3,2),imshow(c),title('Inverted Image 1');
subplot(3,3,3),imshow(b),title('Original Image 2');
subplot(3,3,4),imshow(e),title('Converted to GrayScale');
subplot(3,3,5),imshow(d),title('Inverted Image 2');
