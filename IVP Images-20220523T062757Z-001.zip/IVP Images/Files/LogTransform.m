close all
clear all
clc
pkg load image
a=imread('Sunflower.jpg');
h=rgb2gray(a);
d=imread('Tree.jpg');
i=rgb2gray(d);
b=im2double(h);
e=im2double(i);
c=2;
f=c*log(1+(b));
g=c*log(1+(e));
subplot(3,3,1),imshow(a),title('Original Image');
subplot(3,3,2),imshow(h),title('Grayscale Image');
subplot(3,3,3),imshow(f),title('Log Transformation Image');
subplot(3,3,4),imshow(d),title('Original Image');
subplot(3,3,5),imshow(i),title('GrayScale Image');
subplot(3,3,6),imshow(g),title('Log Transformation Image');

