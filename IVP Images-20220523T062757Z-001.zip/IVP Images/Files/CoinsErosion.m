pkg load image;
org_im = imread('coins.png');
subplot(1,3,1); imshow(org_im); title('Original Image');
#Convert RGB image to Binary Image and Displayed as Input Image
A=im2bw(org_im);
se=strel('disk',1,0);
F=imerode(A,se);
subplot(1,3,2); imshow(F);title("eroded");
subplot(1,3,3); imshow(A-F); title("boundary");