close all
clear all
pkg load image
a=imread('Butterfly.jfif');
b=rgb2gray(a);
subplot(1,2,1),imshow(a),title('Original Image');
subplot(1,2,2),imshow(b),title('Grayscale Image');
imread(b);
