close all;
clear all;
clc;
pkg load image;
[img1 path]= uigetfile('*.*');
b=imread(img1);
a=rgb2gray(b);
[r c p]=size(a);
thr=input('Enter value of Threshold : ');
for i=1:r
  for j=1:c
    if(a(i,j)>thr)
    out(i,j)=1;
    else
    out(i,j)=0;
    end
  end
end
subplot(3,3,1),imshow(b),title('Input Image');
subplot(3,3,4),imhist(b),title('Histogram of an Input Image');
subplot(3,3,2),imshow(a),title('Image Converted to Gray');
subplot(3,3,5),imhist(a),title('Histogram Gray Scale Image');
subplot(3,3,3),imshow(out),title('Threshold Image');
subplot(3,3,6),imhist(out),title('Histogram of Threshold Image');
