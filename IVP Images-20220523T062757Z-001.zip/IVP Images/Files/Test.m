clc;
close all;
clear all;
%read the test image%convert the image to binary image
myorigimg = imread('test.jpg');
myorigimg = im2bw(rgb2gray(myorigimg));
subplot(3,3,1);
imshow(myorigimg);title('Original Image');
%create structuring element
se = strel('disk',9,0);
%perform dilation operation using imdilate command_line_path
%Display the dilated image
mydilatedimg = imdilate(myorigimg,se);
subplot(3,3,2);
imshow(mydilatedimg);title('Dilated Image');
%perform Erosion operation using imerode command
%Display the eroded image
myerodedimg = imerode(myorigimg,se);
subplot(3,3,3);
imshow(myerodedimg);title('Eroded Image');
%Find internal Boundary
%internal Boundary = Dilated image AND NOT of eroded image
% Display internal boundary
internalboundingimg = mydilatedimg & ~myerodedimg;
subplot(3,3,4);
imshow(internalboundingimg, []);title('Internal Boundary');
%Find external boundary, external boundary = dilated image AND Not of original image
%Display external boundary
externalboundimg = mydilatedimg & ~myorigimg;
subplot(3,3,5);
imshow(externalboundimg,[]);title('External Boundary');
%Find morphological gradient
mymorphgradimg = imsubtract(myorigimg,myerodedimg);
subplot(3,3,6);
imshow(mymorphgradimg,[]);title('Morphological Gradient');

%Perform Thinning operation Using bwmorph()
thinf =bwmorph(myorigimg,'thin');
subplot(3,3,7);
imshow(thinf);title('Thinning of the Image');
%Perform Thickening operation using bwmorph()
thickf = bwmorph(myorigimg,'thicken');
subplot(3,3,8);
imshow(thickf);title('Thickening of the Image');

%Perform skeletonization operation using bwmorph() command
%with 8 iterations and display the dilated image
skelf100 = bwmorph(myorigimg,'skel',8);
subplot(3,3,9);
imshow(skelf100);title('skeletonization - 9 iterations');