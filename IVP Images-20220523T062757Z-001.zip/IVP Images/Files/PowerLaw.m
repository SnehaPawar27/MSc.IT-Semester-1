pkg load image;
clear all;
close all;
x = imread('lena_gray_256.tif');
#x = rgb2gray(x); #Converting RGB image to gray-level image
x = im2double(x);
[row col] = size(x);
gamma=2;
c=1;
for i = 1:row
for j = 1:col
N(i,j)=c*(x(i,j)^gamma);
endfor
endfor
subplot(1,2,1);imshow(x); title('Original Image');
subplot(1,2,2); imshow(N); title('Gamma Transformation Filtered Image');